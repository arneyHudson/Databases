from pymongo.mongo_client import MongoClient
from dotenv import load_dotenv

load_dotenv()
uri = ("mongodb+srv://arneyh:SRDgilYuXK4SPiqy@cluster0.d3tegli.mongodb.net/"
       "?retryWrites=true&w=majority&appName=Cluster0")

client = MongoClient(uri)
client.admin.command('ping')
# print("Pinged your deployment. You successfully connected to MongoDB!")

# print("\nDatabases in MongoDB Client:")
# for db_info in client.list_database_names():
# print("\t", db_info)

db = client["FinalProject"]
# print("\nCollections in FinalProject Database:")
# for db_info in db.list_collection_names():
# print("\t", db_info)

# collections = db.list_collection_names()
# for collection_name in collections:
    # print(f"Collection: {collection_name}")
    # collection = db[collection_name]
    # sample_document = collection.find_one()
    # if sample_document:
        # print("Features:")
        # for feature in sample_document:
            # print(f"\t{feature}")

colors = [
    '\033[0;91;4m',  # Red
    '\033[38;2;255;140;0;4m',  # Orange
    '\033[0;93;4m',  # Yellow
    '\033[0;92;4m',  # Green
    '\033[0;96;4m',  # Cyan
    '\033[0;94;4m',  # Blue
    '\033[0;35;4m',  # Purple
    '\033[0;95;4m'  # Pink
]

reset_color = '\033[0m'

questions_printed = False


def count_videos_by_category():
    """
    Question 1 - List the number of videos for each video category.

    SQL Query Used:
        select category, COUNT(*) from recording group by category;
    """

    pipeline = [
        {"$match": {"Category": {"$exists": True, "$ne": None}}},
        {"$group": {"_id": "$Category", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}}
    ]

    try:
        make_count_table(db["recording"], pipeline, 1)
    except Exception as e:
        print("An error occurred:", e)


def count_videos_with_non_zero_inventory_by_category():
    """
    Question 2 - List the number of videos for each video category where the inventory is non-zero.

    SQL Query Used:
        select category, count(*) from recording where Stock_Count > 0 group by category;
    """

    pipeline = [
        {"$match": {"Category": {"$exists": True, "$ne": None}}},
        {"$match": {"Stock_Count": {"$gt": 0}}},  # Filter out documents with Inventory > 0
        {"$group": {"_id": "$Category", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}}
    ]

    try:
        make_count_table(db["recording"], pipeline, 2)
    except Exception as e:
        print("An error occurred:", e)


def list_categories_for_actor():
    """
    Question 3 - For each actor, list the video categories that actor has appeared in.

    SQL Query Used:
        SELECT Actor.Name AS Actor_Name, Category.Name AS Category_Name FROM Actor
        JOIN Associated_With ON Actor.Actor_ID = Associated_With.Actor_ID
        JOIN Recording ON Associated_With.Recording_ID = Recording.Recording_ID
        JOIN Category ON Recording.Category = Category.Name
        ORDER BY Actor_Name, Category_Name;
    """

    pipeline = [
        {"$lookup": {"from": "actor", "localField": "Actor_ID", "foreignField": "Actor_ID", "as": "actor"}},
        {"$unwind": "$actor"},
        {"$lookup": {"from": "recording", "localField": "Recording_ID", "foreignField": "Recording_ID",
                     "as": "recording"}},
        {"$unwind": "$recording"},
        {"$lookup": {"from": "category", "localField": "recording.Category", "foreignField": "Name", "as": "category"}},
        {"$unwind": "$category"},
        {"$group": {"_id": "$actor.Name", "Category": {"$addToSet": "$category.Name"}}},
        {"$project": {"Actor/Actress": "$_id", "Category": {"$reduce": {"input": "$Category", "initialValue": "",
                                                                        "in": {"$concat": ["$$value", {
                                                                            "$cond": [{"$eq": ["$$value", ""]}, "",
                                                                                      ", "]}, "$$this"]}}}, "_id": 0}},
        {"$sort": {"Actor/Actress": 1}}
    ]

    try:
        first_document = db.associated_with.aggregate(pipeline).next()
        column_names = list(first_document.keys())

        make_table(db.associated_with, pipeline, column_names, 3)
    except Exception as e:
        print("An error occurred:", e)


def actors_in_different_categories():
    """
    Question 4: Which actors have appeared in movies in different video categories?

    Query Used:
        SELECT Actor.Name AS Actor_Name, COUNT(DISTINCT Category.Name) AS Num_Different_Categories FROM Actor
        JOIN Associated_With ON Actor.Actor_ID = Associated_With.Actor_ID
        JOIN Recording ON Associated_With.Recording_ID = Recording.Recording_ID
        JOIN Category ON Recording.Category = Category.Name
        GROUP BY Actor.Name
        HAVING Num_Different_Categories > 1
        ORDER BY Num_Different_Categories DESC;
    """

    pipeline = [
        {"$lookup": {"from": "associated_with", "localField": "Actor_ID", "foreignField": "Actor_ID",
                     "as": "associated_with"}},
        {"$unwind": "$associated_with"},
        {"$lookup": {"from": "recording", "localField": "associated_with.Recording_ID", "foreignField": "Recording_ID",
                     "as": "recording"}},
        {"$unwind": "$recording"},
        {"$lookup": {"from": "category", "localField": "recording.Category", "foreignField": "Name", "as": "category"}},
        {"$unwind": "$category"},
        {"$group": {"_id": "$Name", "Number of Unique Categories": {"$addToSet": "$category.Name"}}},
        {"$project": {"Actor/Actress": "$_id", "Number of Unique Categories": {"$size": "$Number of Unique Categories"}}},
        {"$match": {"Number of Unique Categories": {"$gt": 1}}},
        {"$sort": {"Number of Unique Categories": -1, "Actor/Actress": 1}},
        {"$project": {"Actor/Actress": 1, "Number of Unique Categories": 1, "_id": 0}}
    ]

    try:
        first_document = db.actor.aggregate(pipeline).next()
        column_names = list(first_document.keys())

        make_table(db.actor, pipeline, column_names, 4)
    except Exception as e:
        print("An error occurred:", e)


def actors_not_in_comedy():
    """
    Question 5: Which actors have not appeared in a comedy?

    Query Used:
        SELECT DISTINCT Name AS Actor_Name FROM Actor
        WHERE Actor_ID NOT IN (
        SELECT DISTINCT Actor_ID FROM Associated_With
        JOIN Recording ON Associated_With.Recording_ID = Recording.Recording_ID
        WHERE Recording.Category = 'Comedy');
    """

    pipeline = [
        {"$lookup": {"from": "actor", "localField": "Name", "foreignField": "Name",
                     "as": "actor"}},
        {"$lookup": {"from": "recording", "localField": "actor.Recording_ID", "foreignField": "Recording_ID",
                     "as": "recordings"}},
        {"$match": {"recordings.Category": {"$ne": "Comedy"}}},
        {"$project": {"_id": 0, "Name": 1, "Category": "$recordings.Category"}},
        {"$unwind": "$Category"},
        {"$group": {"_id": "$Name", "Categories": {"$addToSet": "$Category"}}},
        {"$addFields": {"Actor/Actress": "$_id", "Category(ies)": {"$reduce": {
            "input": "$Categories",
            "initialValue": "",
            "in": {"$concat": ["$$value", {"$cond": [{"$eq": ["$$value", ""]}, "", ", "]}, "$$this"]}}}}},
        {"$project": {"_id": 0, "Actor/Actress": 1}},
        # add this: ', "Category(ies)": 1' if you want to see categories as well
        {"$sort": {"Actor/Actress": 1}}
    ]

    try:
        first_document = db.actor.aggregate(pipeline).next()
        column_names = list(first_document.keys())

        make_table(db.actor, pipeline, column_names, 5)
    except Exception as e:
        print("An error occurred:", e)


def actors_in_comedy_and_action_adventure():
    """
    Question 6: Which actors have appeared in both a comedy and an action adventure movie?

    Query Used:
        SELECT DISTINCT a.Name AS Actor_Name FROM Actor a
        JOIN Associated_With aw ON a.Actor_ID = aw.Actor_ID
        JOIN Recording r ON aw.Recording_ID = r.Recording_ID
        JOIN Category c ON r.Category = c.Name
        WHERE c.Name IN ('Comedy', 'Action & Adventure')
        GROUP BY a.Name
        HAVING COUNT(DISTINCT CASE WHEN c.Name = 'Comedy' THEN r.Recording_ID END) > 0
        AND COUNT(DISTINCT CASE WHEN c.Name = 'Action & Adventure' THEN r.Recording_ID END) > 0;
    """

    pipeline = [
        {"$lookup": {"from": "associated_with", "localField": "Actor_ID", "foreignField": "Actor_ID",
                     "as": "associated_with"}},
        {"$unwind": "$associated_with"},
        {"$lookup": {"from": "recording", "localField": "associated_with.Recording_ID", "foreignField": "Recording_ID",
                     "as": "recording"}},
        {"$unwind": "$recording"},
        {"$lookup": {"from": "category", "localField": "recording.Category", "foreignField": "Name", "as": "category"}},
        {"$unwind": "$category"},
        {"$match": {"category.Name": {"$in": ["Comedy", "Action & Adventure"]}}},
        {"$group": {"_id": "$Name",
                    "Comedy_count": {"$sum": {"$cond": [{"$eq": ["$category.Name", "Comedy"]}, 1, 0]}},
                    "Action_count": {"$sum": {"$cond": [{"$eq": ["$category.Name", "Action & Adventure"]}, 1, 0]}}}},
        {"$match": {"Comedy_count": {"$gt": 0}, "Action_count": {"$gt": 0}}},
        {"$project": {"Actor/Actress": "$_id", "_id": 0}},
        {"$sort": {"Actor/Actress": 1}}
    ]
    try:
        first_document = db.actor.aggregate(pipeline).next()
        column_names = list(first_document.keys())

        make_table(db.actor, pipeline, column_names, 6)
    except Exception as e:
        print("An error occurred:", e)


def actors_in_multiple_ratings_and_categories():
    """
    Question 7: Which actors appear in both multiple ratings and categories?

    Query Used:
        SELECT DISTINCT
            a.Name AS Actor_Name,
            Num_Different_Ratings,
            Rating_Names,
            Num_Different_Categories,
            Category_Names
        FROM Actor a
        JOIN (
            SELECT
                a.Name AS Actor_Name,
                COUNT(DISTINCT r.Rating) AS Num_Different_Ratings,
                GROUP_CONCAT(DISTINCT r.Rating ORDER BY r.Rating) AS Rating_Names,
                COUNT(DISTINCT r.Category) AS Num_Different_Categories,
                GROUP_CONCAT(DISTINCT r.Category ORDER BY r.Category) AS Category_Names
            FROM Associated_With aw
            JOIN Recording r ON aw.Recording_ID = r.Recording_ID
            JOIN Actor a ON aw.Actor_ID = a.Actor_ID
            GROUP BY a.Name
        ) AS Counts ON a.Name = Counts.Actor_Name
        WHERE Num_Different_Ratings > 1 AND Num_Different_Categories > 1;
    """

    pipeline = [
        {"$lookup": {"from": "associated_with", "localField": "_id", "foreignField": "_id",
                     "as": "associated_with"}},
        {"$unwind": "$associated_with"},
        {"$lookup": {"from": "recording", "localField": "associated_with.Recording_ID", "foreignField": "Recording_ID",
                     "as": "recording"}},
        {"$unwind": "$recording"},
        {"$group": {"_id": "$Name", "Number of Unique Ratings": {"$addToSet": "$recording.Rating"},
                    "Number of Unique Categories": {"$addToSet": "$recording.Category"}}},
        {"$project": {
            "Actor/Actress": "$_id",
            "Number of Unique Ratings": {"$size": "$Number of Unique Ratings"},
            "Ratings": {"$reduce": {"input": "$Number of Unique Ratings", "initialValue": "", "in": {
                "$concat": ["$$value", {"$cond": [{"$eq": ["$$value", ""]}, "", ", "]}, "$$this"]}}},
            "Number of Unique Categories": {"$size": "$Number of Unique Categories"},
            "Categories": {"$reduce": {"input": "$Number of Unique Categories", "initialValue": "", "in": {
                "$concat": ["$$value", {"$cond": [{"$eq": ["$$value", ""]}, "", ", "]}, "$$this"]}}},
            "_id": 0
        }},
        {"$sort": {"Number of Unique Categories": -1, "Actor/Actress": 1}},
        {"$match": {"Number of Unique Ratings": {"$gt": 1}, "Number of Unique Categories": {"$gt": 1}}}
    ]

    try:
        first_document = db.actor.aggregate(pipeline).next()
        column_names = list(first_document.keys())

        make_table(db.actor, pipeline, column_names, 7)
    except Exception as e:
        print("An error occurred:", e)


def actor_is_also_director():
    """
    Brand new made up for this lab
    """
    pipeline = [
        {"$lookup": {"from": "director", "localField": "Name", "foreignField": "Name", "as": "matching_directors"}},
        {"$unwind": {"path": "$matching_directors", "preserveNullAndEmptyArrays": True}},
        {"$match": {"matching_directors": {"$exists": True}}},
        {"$group": {"_id": "$Name"}},
        {"$sort": {"_id": 1}},
        {"$project": {"Actor_Name": "$_id", "_id": 0}}
    ]

    try:
        first_document = db.actor.aggregate(pipeline).next()
        column_names = list(first_document.keys())

        make_table(db.actor, pipeline, column_names, 8)
    except Exception as e:
        print("An error occurred:", e)


def make_count_table(collection, pipeline, question_number):
    total_instances = 0
    result = collection.aggregate(pipeline)

    for doc in result:
        total_instances += doc["count"]

    result = collection.aggregate(pipeline)

    print("+" + ("-" * 45) + "+")
    print("|", "Category".center(20), "|", str("Count (total = " + str(total_instances) + ")").center(20), "|")
    print("|" + "-" * 22 + "|" + "-" * 22 + "|")

    color_index = 0  # Initialize color index
    total_entries = 0

    for doc in result:
        # Choose color from the rainbow
        color = colors[color_index % len(colors)]
        color_index += 1  # Move to the next color
        print("|", color + str(doc["_id"]).center(20) + reset_color, "|",
              color + str(doc["count"]).center(20) + reset_color, "|")
        total_entries += 1

    print("+" + ("-" * 45) + "+")
    print(f"Question {question_number} Total Entries: {total_entries}")



def make_table(collection, pipeline, column_names, question_number):
    result = collection.aggregate(pipeline)

    total_entries = 0

    num_columns = len(column_names)
    column_width = 50
    total_width = num_columns * (column_width + 3) + 1

    if_one_column = 4
    if_two_column = 6
    if_more = 12

    if len(column_names) == 1:
        placeholder = if_one_column
    elif len(column_names) == 2:
        placeholder = if_two_column
    else:
        placeholder = if_more

    print("+" + "-" * (total_width - placeholder) + "+")

    header = "|"
    for column_name in column_names:
        header += column_name.center(column_width) + "|"
    print(header)

    print("+" + "-" * (total_width - placeholder) + "+")

    color_index = 0

    for doc in result:
        data_row = "|"
        for column_name in column_names:
            data_row += (colors[color_index % len(colors)] +
                         str(doc[column_name]).center(column_width) +
                         reset_color + "|")
        print(data_row)
        color_index += 1
        total_entries += 1

    print("+" + "-" * (total_width - placeholder) + "+")
    print(f"Question {question_number} Total Entries: {total_entries}")

def print_questions():
    print("Select an option:")
    print("\t\033[1;91m1. List the number of videos for each video category.\033[0m")  # Red
    print("\t\033[38;2;255;165;1m2. List the number of videos for each video category "
          "where the inventory is non-zero.\033[0m")  # Custom Orange
    print("\t\033[1;93m3. For each actor, list the video categories that actor has appeared in.\033[0m")  # Yellow
    print("\t\033[1;92m4. Which actors have appeared in movies in different video categories?\033[0m")  # Green
    print("\t\033[1;96m5. Which actors have not appeared in a comedy?\033[0m")  # Cyan
    print(
        "\t\033[1;94m6. Which actors have appeared in both a comedy and an action adventure movie?\033[0m")  # Blue
    print("\t\033[1;35m7. Which actors have appeared in both multiple ratings and categories?\033[0m")  # Purple
    print("\t\033[1;95m8. Which directors have also been actors?\033[0m")  # Pink
    print("\t9. Exit")

def intro():
    print("\nWelcome to my Databases Final Project!\n"
          "\nThe following will prompt you to enter a number to answer the following questions\n"
          "Upon completion it will connect to my MongoDB database, access necessary information,\n"
          "and print a nicely formatted table to answer your question!\n"
          "\nI hope you find this helpful!")
def main():
    intro()
    global questions_printed
    while True:
        print()
        print("*" * 100)
        if not questions_printed:
            print_questions()
            questions_printed = True
        else:
            print("Enter a number to select an option or type '\033[1mhelp\033[0m' to see the questions again.")

        print("*" * 100)
        choice = input("Enter your choice: ")

        if choice == "1":
            count_videos_by_category()
        elif choice == "2":
            count_videos_with_non_zero_inventory_by_category()
        elif choice == "3":
            list_categories_for_actor()
        elif choice == "4":
            actors_in_different_categories()
        elif choice == "5":
            actors_not_in_comedy()
        elif choice == "6":
            actors_in_comedy_and_action_adventure()
        elif choice == "7":
            actors_in_multiple_ratings_and_categories()
        elif choice == "8":
            actor_is_also_director()
        elif choice == "9":
            break
        elif choice.lower() == "help":
            questions_printed = False
        else:
            print("Invalid choice. Please try again.")
            continue
        print()
        print("*" * 100)
        enter_command = input("Press Enter to continue (or type 'exit' to quit): ")
        if enter_command.lower() == "exit":
            break


if __name__ == "__main__":
    main()
