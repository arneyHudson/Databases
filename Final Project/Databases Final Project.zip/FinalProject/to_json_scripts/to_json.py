import json

def convert_video_actors_to_json(input_file, output_file):
    actors = []
    with open(input_file, 'r') as f:
        for line in f:
            data = line.strip().split('\t')
            actor_id = int(float(data[0]))
            actor_name = data[1].strip('"')
            recording_id = int(float(data[2]))
            actors.append({"id": actor_id, "name": actor_name, "recording_id": recording_id})
    
    with open(output_file, 'w') as f:
        json.dump(actors, f, indent=4)

def convert_video_categories_to_json(input_file, output_file):
    categories = []
    with open(input_file, 'r') as f:
        for line in f:
            data = line.strip().split('\t')
            category_id = int(float(data[0]))
            category_name = data[1].strip('"')
            categories.append({"id": category_id, "name": category_name})
    
    with open(output_file, 'w') as f:
        json.dump(categories, f, indent=4)

def convert_video_recordings_to_json(input_file, output_file):
    recordings = []
    with open(input_file, 'r') as f:
        for line in f:
            data = line.strip().split('\t')
            recording_id = int(float(data[0]))
            director = data[1].strip('"')
            title = data[2].strip('"')
            category = data[3].strip('"')
            image_name = data[4].strip('"')
            duration = float(data[5])
            rating = data[6].strip('"')
            year_released = int(float(data[7]))
            price = float(data[8])
            stock_count = int(float(data[9]))
            recordings.append({
                "recording_id": recording_id,
                "director": director,
                "title": title,
                "category": category,
                "image_name": image_name,
                "duration": duration,
                "rating": rating,
                "year_released": year_released,
                "price": price,
                "stock_count": stock_count
            })
    
    with open(output_file, 'w') as f:
        json.dump(recordings, f, indent=4)

# Example usage
convert_video_actors_to_json("video_actors.txt", "video_actors.json")
convert_video_categories_to_json("video_categories.txt", "video_categories.json")
convert_video_recordings_to_json("video_recordings.txt", "video_recordings.json")
